<?php $__currentLoopData = $comments->sortByDesc('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
<div class="container">
    <main role="main" class="container"> 
        <div class="row">
            <div class="blog-comment">
                <div class="container">
                    <div class="row">      
                        <div class="col-sm-1" style="max-width:100% !important;">
                            <div class="thumbnail">
                                <img class="img-responsive user-photo" src="/storage/cover_images/<?php echo e($comment->user->profile_image); ?>" alt="profile_image" style="width:100%">
                            </div><!-- /thumbnail -->
                        </div><!-- /col-sm-1 -->

                        <div class="col-sm-5" style="max-width: 100% !important; flex: 1;">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <strong><?php echo e($comment->user->fname); ?> <?php echo e($comment->user->lname); ?></strong> <span class="text-muted"><?php echo e($comment->created_at->diffforHumans()); ?></span>
                                </div>
                                    <div class="panel-body">
                                        <?php echo e($comment->body); ?>

                                    </div><!-- /panel-body -->
                                </div><!-- /panel panel-default -->
                            </div><!-- /col-sm-5 -->
                        </div>
                        <?php if(auth::user()): ?>
                        <a href="" id="reply"></a>
                        <form method="post" action="<?php echo e(route('reply.add')); ?>" id="reply">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <input type="text" name="body" class="form-control" required="required" />
                                <input type="hidden" name="post_id" value="<?php echo e($post_id); ?>" />
                                <input type="hidden" name="comment_id" value="<?php echo e($comment->id); ?>" />
                                <input type="hidden" name="user_id" value="<?php echo e($comment->user->id); ?>" />
                            </div>
                            <div class="form-group">
                                <input type="submit" class="btn btn-warning comment" value="Reply" />
                            </div>
                        </form>
                        <?php endif; ?>
                        <hr>
                        <?php echo $__env->make('partials.comment', ['comments' => $comment->replies], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        <hr>   
                    </div>
                </div>
            </div>  
        </div>
    </main>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   

