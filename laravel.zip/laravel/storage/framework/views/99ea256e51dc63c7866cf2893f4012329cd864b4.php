<?php $__env->startSection('content'); ?>
<div class="col-sm-2">

</div>
    <?php if(isset($msg_in)): ?>
        <?php $__currentLoopData = $msg_in; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-8" >
                <div class="row">
                    <h2>Message</h2>
                    <hr>
                    <a href="<?php echo e(route('back')); ?>"><i class="fa fa-long-arrow-left" aria-hidden="true"></i> back</a>
                </div>
                <div class="row">
                    <table class="msg" style="width:100%" cellpadding="0" cellspacing="0">
                        <tr>
                            <td style="width:100%"><p>From : <a href="/profile/<?php echo e($inc->user_id); ?>"><?php echo e($inc->fname); ?> <?php echo e($inc->lname); ?></a></p></td>
                        </tr>
                        <tr>
                            <td style="width:100%"><p>Subject : <?php echo e($inc->subject); ?></p><hr></td>
                        </tr>
                        <tr>
                            <td style="width:100%"><p><?php echo e($inc->message); ?></p></td>
                        </tr>
                        <tr>
                            <td style="padding-right:15px">
                                <a href="<?php echo e(route('create', [$name = $inc->username])); ?>">
                                    <span class="pull-right">
                                        <button class="btn btn-success btn-sm">Reply</button>
                                    </span>
                                </a>
                            </td>
                        </tr>
                    </table>                    
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>

    <?php if(isset($msg_out)): ?>
        <?php $__currentLoopData = $msg_out; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-8" >
                <div class="row">
                    <h2>Message</h2>
                    <hr>
                    <a href="<?php echo e(route('back')); ?>"><i class="fa fa-long-arrow-left" aria-hidden="true"></i> back</a>
                </div>
                <div class="row">
                    <table class="msg" style="width:100%" cellpadding="0" cellspacing="0">
                        <tr>
                            <td style="width:100%"><p>To : <a href="/profile/<?php echo e($sent->user_id); ?>"><?php echo e($sent->fname); ?> <?php echo e($sent->lname); ?></a></p></td>
                        </tr>
                        <tr>
                            <td style="width:100%"><p>Subject : <?php echo e($sent->subject); ?></p><hr></td>
                        </tr>
                        <tr>
                            <td style="width:100%"><p><?php echo e($sent->message); ?></p></td>
                        </tr>
                    </table>                    
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<div class="col-sm-2">

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>