<?php $__env->startSection('content'); ?>
<div class="col-md-8 blog-main">
    <h3 class="pb-3 mb-4 font-italic border-bottom">
    <?php echo e(count($posts)); ?> Result for <?php echo e($searchTerm); ?>

    </h3>
    <?php if(count($posts) > 0): ?>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="blog-post">
            <div class="row">
                <h2 class="blog-post-title"><?php echo e($post->title); ?></h2>
                <hr>
            </div>
            <small>Category : <?php echo e($post->kategori); ?></small><br>
            <small class="blog-post-meta"><?php echo e($post->created_at); ?> by <a href="/profile/<?php echo e($post->user->id); ?>"><?php echo e($post->user->fname); ?> <?php echo e($post->user->lname); ?></a></small>
            <img style="width:50%; height:50%; display:block; margin-left:auto; margin-right: auto;" src="/storage/cover_images/<?php echo e($post->cover_image); ?>">
            <br><br>
            <p><?php echo str_limit($post->body, $limit = 150, $end = '...'); ?><a href="/posts/<?php echo e($post->id); ?>"> ->Details</a></p>
            
        </div><!-- /.blog-post -->
        <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($posts->links()); ?>

    <?php else: ?>
        <p>No posts found</p>
    <?php endif; ?>
</div><!-- /.blog-main -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>