<div class="row mb-2" >
    <?php $__currentLoopData = $popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-6" >    
        <div class="card flex-md-row mb-4 shadow-sm h-md-250" style="height:100%">
        <div class="card-body d-flex flex-column align-items-start">
            <strong class="d-inline-block mb-2 text-primary">Most Popular Author</strong>
            <h3 class="mb-0">
            <a class="text-dark"><?php echo $u->followable->fname; ?> <?php echo $u->followable->lname; ?></a>
            </h3>
            <div class="mb-1 text-muted"><?php echo e($u->followable->job); ?></div>
            <div>
                <p class="card-text mb-auto lead"><?php echo str_limit($u->followable->bio, $limit = 60, $end = '...'); ?></p>      
                <br>    
                <a href="/profile/<?php echo e($u->followable_id); ?>"><i class="fa fa-long-arrow-right" aria-hidden="true"></i> Profile</a>
                <hr>    
                <small>
                    <span class="give-like" style="font-size:16px">Follower <i class="fa fa-users" style="cursor:default;" aria-hidden="true"></i></span><span class="thumb" style="font-size:16px"><?php echo e($u->count); ?></span>
                </small>
            </div>

        </div>
            <img style="width:30%; height:100%" class="card-img-right flex-auto d-none d-lg-block" src="/storage/cover_images/<?php echo e($u->followable->profile_image); ?>" alt="Card image cap">
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<div class="or-seperator" style="margin-top:5em"></div>