@extends('layouts.app')

@section('content')
<div class="card">
  <h5 class="card-header">WELCOME</h5>
  <div class="card-body">
    <img src="https://randomuser.me/api/portraits/women/81.jpg" class="img-responsive" alt="Responsive image">
    <h5 class="card-title">Hi <strong>User!</strong></h5>
    <p class="card-text">Please enter your new password for Artikel!</p>
    <form class="form-horizontal" role="form" method="POST" action="{{ url('/register') }}">
        <div class="form-group">
            <label class="col-sm-2 control-label">Email</label>
            <div class="col-sm-10">
            <p class="form-control-static">email@example.com</p>
            </div>
        </div>
        <div class="form-group {{ $errors->has('password') ? ' has-error' : '' }}">
            <label for="inputPassword" class="col-sm-2 control-label">Password</label>
            <div class="col-sm-10">
                <input type="password" class="form-control" id="inputPassword" placeholder="Password" name="password" required>
                @if ($errors->has('password'))
                    <span class="help-block">
                        <strong>{{ $errors->first('password') }}</strong>
                    </span>
                @endif
            </div>
        </div>

        <div class="form-group">
            <label for="password-confirm" class="col-sm-2 control-label">Confirm</label>
            <div class="col-sm-10">
                <input type="password" class="form-control" id="password-confirm" placeholder="Confirm" name="password_confirmation" required>
            </div>
        </div>

        <div class="form-group">
            <div class="col-md-6" style="text-align: center;width: 100%;">
                <button type="submit" class="btn btn-primary">
                    Complete
                </button>
            </div>
        </div>
    </form>
  </div>
</div>

@endsection