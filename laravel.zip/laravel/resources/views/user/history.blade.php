@extends('layouts.app')

@section('content')
<div class="col-sm-2">

</div>

<div class="col-md-8" >
    <div class="row">
        <h2>ACTIVITY</h2>
        <hr>
        <a href="{{route('back')}}"><i class="fa fa-long-arrow-left" aria-hidden="true"></i> back</a>
    </div>      
    <hr>          
    <div class="row">
    @if(count($notify) > 0)
        <div class="col">
            <ul class="list-group-striped">
                @foreach($notify as $notification)
                    <li class="dropdown-header" style="padding: 0.5rem 0.5rem !important; word-break: break-word; width:100%; overflow:hidden; text-overflow:ellipsis;">
                        @if(empty($notification->relation))
                        <a href="/posts/{{$notification->pid}}" style="padding: 8px 12px !important">{{\Carbon\Carbon::parse($notification->tgl)->diffforHumans()}} : <b style="color:blue">{{$notification->fullname}}</b>
                        comment <b style="color:blue">"{{$notification->comment}}"</b> on your post <b style="color:blue">"{{$notification->post}}"</b>!</a>
                        @elseif($notification->relation == 'like')
                        <a href="/posts/{{$notification->pid}}" style="padding: 8px 12px !important">{{\Carbon\Carbon::parse($notification->tgl)->diffforHumans()}} : <b style="color:blue">{{$notification->fullname}}</b> {{$notification->relation}} your post <b style="color:blue">"{{$notification->post}}"</b>!</a>
                        @else
                        <a href="/profile/{{$notification->id}}" style="padding: 8px 12px !important">{{\Carbon\Carbon::parse($notification->tgl)->diffforHumans()}} : <b style="color:blue">{{$notification->fullname}}</b> {{$notification->relation}} you!</a>
                        @endif
                    </li>  
                @endforeach   
            </ul>

        </div> 
    @else
        <p style='text-align:center'>You don't have follower!</p>  
    @endif   
    </div>
</div>

<div class="col-sm-2">

</div>
@endsection