@extends('layouts.app')

@section('content')
<div class="col-sm-2">

</div>
    @isset($follower)
        <div class="col-md-8" >
            <div class="row">
                <h2>Follower</h2>
                <hr>
                <a href="{{route('back')}}"><i class="fa fa-long-arrow-left" aria-hidden="true"></i> back</a>
            </div>      
            <hr>          
            <small>{{Auth::user()->followers()->get()->count()}} Total followers</small>
            <div class="row">
            @if(count($follower) > 0)
            @foreach($follower as $follower)
                <div class="col-sm-4">
                    <div class="panel">
                        <div class="image">
                            <img src="/storage/cover_images/{{$follower->profile_image}}" alt="" width="100%" height="100%" style="border-radius: 50%;">
                        </div>
                        <hr>
                        <p style="width:100%; margin-bottom: 1px !important; text-align:center"><a href="{{route('create', [$name = $follower->username])}}" title="Send Message" >{{$follower->fname}} {{$follower->lname}}</a></p>
                    </div>
                </div>      
            @endforeach   
            @else
                <p style='text-align:center'>You don't have follower!</p>  
            @endif   
            </div>
        </div>
    @endisset

    @isset($following)
        <div class="col-md-8" >
            <div class="row">
                <h2>Following</h2>
                <hr>
                <a href="{{route('back')}}"><i class="fa fa-long-arrow-left" aria-hidden="true"></i> back</a>
            </div>
            <hr>
            <small>{{Auth::user()->followings()->get()->count()}} Total following</small>
            <div class="row">
            @if(count($following) > 0)
            @foreach($following as $following)
                <div class="col-sm-4">
                    <div class="panel">
                        <div class="image">
                            <img src="/storage/cover_images/{{$following->profile_image}}" alt="" width="100%" height="100%" style="border-radius: 50%;">
                        </div>
                        <hr>
                        <p style="width:100%; margin-bottom: 1px !important; text-align:center"><a href="{{route('create', [$name = $following->username])}}" title="Send Message" >{{$following->fname}} {{$following->lname}}</a></p>
                    </div>
                </div>        
            @endforeach   
            @else
                <p style='text-align:center'>You are not following anyone!</p>  
            @endif          
            </div>
        </div>
    @endisset
<div class="col-sm-2">

</div>
@endsection