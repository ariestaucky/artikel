<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'PagesController@home')->name('home');

Route::get('/blog', 'PagesController@blog')->name('blog');

Route::get('/profile/{id}', 'DashboardController@profile')->name('profile');

// Route::get('/writer', 'UsersController@show');

Route::get('/contact', 'MessagesController@index')->name('contact');

Route::get('/contact/{name}', 'MessagesController@create')->name('create');

Route::get('/message/{id}', 'MessagesController@show')->name('message');

Route::put('/contact/{id}', 'MessagesController@update')->name('read');

Route::delete('/contact/{id}', 'MessagesController@destroy')->name('delete');

Route::get('/back', 'PagesController@back')->name('back');

Route::get('/view', 'PagesController@view')->name('view');

Route::get('/catagory', 'PagesController@catagory')->name('catagory');

Route::get('/search', 'PagesController@search')->name('search');

Route::get('/about', 'PagesController@about')->name('about');

Auth::routes();

Route::get('/dashboard', 'DashboardController@index')->name('dashboard');

Route::resource('posts', 'PostsController');

Route::resource('user', 'UsersController');

Route::post('/contact/submit', 'MessagesController@store')->name('submit');

Route::post('ajaxRequest', 'UsersController@ajaxRequest')->name('ajaxRequest');

Route::post('ajaxRequestLike', 'PostsController@ajaxRequestLike')->name('ajaxRequestLike');

Route::post('ajaxRequestIns', 'PostsController@ajaxRequestIns')->name('ajaxRequestIns');

Route::post('ajaxRequestInsert', 'UsersController@ajaxRequestInsert')->name('ajaxRequestInsert');

Route::group([ 'middleware' => 'auth' ], function () {
    // ...
    Route::get('/notifications', 'UsersController@notifications');
});

Route::post('/comment/store', 'CommentController@store')->name('comment.add');

Route::post('/reply/store', 'CommentController@replyStore')->name('reply.add');

Route::get('/follower', 'UsersController@follower');

Route::get('/following', 'UsersController@following');

Route::get('/history', 'UsersController@history');