<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Comment;
use App\Post;
use Session;
use URL;

class CommentController extends Controller
{
    public function store(Request $request)
    {    
        $this->validate($request, [
            'body'    => 'required',
            'user_id'   => 'required'
        ]);


        $comment = new Comment;
        $comment->body = $request->input('body');
        $comment->user_id = $request->input('user_id');
        $post = Post::find($request->input('post_id'));
        $post->comments()->save($comment);

        $com = Comment::orderBy('created_at','desc');
        return back()->with('comments', $com);
    }
    public function replyStore(Request $request)
    {
        $this->validate($request, [
            'body'    => 'required',
            'user_id'   => 'required'
        ]);


        $reply = new Comment();
        $reply->body = $request->get('body');
        $reply->user()->associate($request->user());
        $reply->parent_id = $request->get('comment_id');
        $post = Post::find($request->get('post_id'));
        $post->comments()->save($reply);

        $com = Comment::orderBy('created_at','desc');
        return back()->with('comments', $com);
    }
}
