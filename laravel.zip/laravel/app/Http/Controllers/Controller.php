<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use App\User;
use App\Message;
use App\Post;
use DB;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function archive() 
    {
        $archive = DB::table('posts')
        ->select(DB::raw('count(*) as `post_count`'), DB::raw('YEAR(created_at) year, MONTH(created_at) month, MONTHNAME(created_at) month_name'))
        ->groupby('year', 'month')
        ->orderBy('year', 'desc')
        ->orderBy('month', 'desc')
        ->limit(12)
        ->get();  

        return $archive;
    }

    public function notif() 
    {
        if(auth()->check()){
            $auth_id = auth()->user()->id;
            $notif = Message::notif($auth_id)
                            ->orderBy('message_created','desc')
                            ->get();
            return $notif;
        }
    }

    public function notify() 
    {
        if(Auth()->check()){
            $auth_id = auth()->user()->id;
            $notify = DB::select(DB::raw("SELECT users.id as id,
                                                concat(users.fname, ' ', users.lname) as fullname,
                                                users.username as username,
                                                followables.relation as relation,
                                                null as pid,
                                                null as post,
                                                null as comment,
                                                followables.created_at as tgl
                                            FROM users
                                            JOIN followables ON followables.user_id = users.id
                                            WHERE followables.user_id != '$auth_id' and followables.notify = '$auth_id' and followables.followable_type = 'App\\\User'
                                            UNION ALL
                                            SELECT users.id as id,
                                                concat(users.fname, ' ', users.lname) as fullname,
                                                users.username as username,
                                                followables.relation as relation,
                                                posts.id as pid,
                                                posts.title as post,
                                                null as comment,
                                                followables.created_at as tgl
                                            FROM users
                                            JOIN followables ON followables.user_id = users.id
                                            JOIN posts ON (CASE
                                                           WHEN followables.followable_type = 'App\\\Post' THEN posts.id = followables.followable_id END)
                                            WHERE followables.user_id != '$auth_id' and followables.notify = '$auth_id'
                                            UNION ALL
                                            SELECT users.id as id,
                                                concat(users.fname, ' ', users.lname) as fullname,
                                                users.username as username,
                                                null as relation,
                                                posts.id as pid,
                                                posts.title as post,
                                                comments.body as comment,
                                                comments.created_at as tgl
                                            FROM users
                                            JOIN comments ON comments.user_id = users.id
                                            JOIN posts ON posts.id = comments.post_id
                                            WHERE posts.user_id = '$auth_id' and comments.user_id != '$auth_id'
                                            ORDER BY tgl DESC") );
            // $first = DB::table('users')
            //             ->select('users.id as id',
    //                             'users.fname as fname',
    //                             'users.lname as lname',
    //                             'users.username as username',
    //                             'followables.relation as relation',
    //                             'null as post',
    //                             'null as comment',
    //                             'followables.created_at as tgl',
    //                             'null as comment_tgl')
            //             ->join('followables', 'followables.user_id', '=', 'users.id')
            //             ->where('followables.user_id', '!=', '$auth_id')
            //             ->where('followables.notify', '=', '$auth_id');
            // $notify = DB::table('users')
            //             ->select('users.id as id',
    //                             'users.fname as fname',
    //                             'users.lname as lname',
    //                             'users.username as username',
    //                             'followables.relation as relation',
    //                             'posts.title as post',
    //                             'null as comment',
    //                             'followables.created_at as tgl',
    //                             'null as comment_tgl')
            //             ->JOIN('comments', 'comments.user_id', '=', 'users.id')
            //             ->JOIN('posts', 'posts.id', '=', 'comments.post_id')
            //             ->WHERE('posts.user_id', '=', '$auth_id') 
            //             ->WHERE('comments.user_id', '!=', '$auth_id')
            //             ->union($first)
            //             ->orderBy('tgl', 'DESC', 'comment_tgl', 'DESC');
            return $notify;
        }

    }

    // public function 
}

            