<?php

namespace App\Http\Controllers;

use Validator;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Notifications\UserFollowed;
use App\User;
use App\Post;
use App\Followable;

class UsersController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    // public function index($id)
    // {
    //     $user = User::findOrFail($id);
    //     return view('user.profile')->with('user', $user);
    // } ALready set in the dashboardcontroller

    public function show($id)
    {
        $notify = $this->notify();
        $notif = $this->notif();
        $user = User::findOrFail($id);
        $post = Post::where('user_id', '=', '$id');
        return view('user.show')->with('user', $user)
                                ->with('post', $post)
                                ->with(compact('notif', 'notify'));
    }

    public function edit($id)
    {
        $notify = $this->notify();
        $notif = $this->notif();
        $user = User::findOrFail($id);
        // Check for correct user
        if(auth()->user()->id !== $user->id){
            return redirect('dashboard')->with('error', 'Unauthorized Page');
        };
        return view('user.edit')->with('user', $user)->with(compact('notif', 'notifys'));
        
    }

    public function update(Request $request, $id)
    {
        $user = User::findOrFail($id);
        $validator = Validator::make($request->all(), [
            'fname' => 'required',
            'lname' => 'required',
            'motto' => 'nullable|string|max:255',
            'bio' => 'nullable|string|max:255',
            'gender' => 'required',
            'status' => 'required',
            'bday' => 'required',
            'address' => 'nullable|string|max:255',
            'city' => 'nullable|string|max:255',
            'country' => 'nullable|string|max:255',
            'job' => 'required|string|max:255',
            'pic' => 'image|nullable|max:599'
        ]);
        if ($validator->fails()) 
        {
            return redirect('user.show')
                        ->withErrors($validator)
                        ->withInput();
        }

        // Handle File Upload
        if($request->hasFile('pic')){
            // Get filename with the extension
            $filenameWithExt = $request->file('pic')->getClientOriginalName();
            // Get just filename
            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
            // Get just ext
            $extension = $request->file('pic')->getClientOriginalExtension();
            // Filename to store
            $fileNameToStore= $filename.'_'.time().'.'.$user->username.'.'.$extension;
            // Upload Image
            $path = $request->file('pic')->storeAs('public/cover_images', $fileNameToStore);
        }
        // Create Post
        $user->fname = $request->input('fname');
        $user->lname = $request->input('lname');
        $user->motto = $request->input('motto');
        $user->bio = $request->input('bio');
        $user->gender = $request->input('gender');
        $user->status = $request->input('status');
        $user->bday = $request->input('bday');
        $user->address = $request->input('address');
        $user->city = $request->input('city');
        $user->country = $request->input('country');
        $user->job = $request->input('job');
        if($request->hasFile('pic')){
            if($user->profile_image != 'default.jpg'){
                // Delete Image
                Storage::delete('public/cover_images/'.$user->profile_image);  
            } 
            $user->profile_image = $fileNameToStore;  
        }
        $user->save();
        $notif =$this->notif();
        $notify = $this->notify();

        return view('user.show')->with('success', 'Profile Updated')->with('user', $user)->with(compact('notif', 'notify'));
    }

    public function follower()
    {
        session(['link' => url()->previous()]);

        $user = User::find(auth()->user()->id);
        $follower = $user->followers()->get();
        $notify = $this->notify();
        $notif = $this->notif();

        return view('user.follower')->with(compact('follower', 'notif', 'notify'));
    }

    public function following()
    {
        session(['link' => url()->previous()]);

        $user = User::find(auth()->user()->id);
        $following = $user->followings()->get();
        $notify = $this->notify();
        $notif = $this->notif();

        return view('user.follower')->with(compact('following', 'notif', 'notify'));
    }

    public function history()
    {
        $notify = $this->notify();
        $notif = $this->notif();

        return view('user.history')->with(compact('notif', 'notify'));
    }

    public function complate(Request $request, $id)
    {
        $user = User::findOrFail($id);
        $validator = Validator::make($request->all(), [
            'password' => ['required', 'string', 'min:6', 'confirmed'],
        ]);
        if ($validator->fails()) 
        {
            return redirect('auth.social')
                        ->withErrors($validator);
        }

        // Create Post
        $user->password = Hash::make($request->input('password'));
        $user->save();

        $notif =$this->notif();
        $notify = $this->notify();

        return view('dashboard')->with('success', 'Welcome to Artikel!')->with('user', $user)->with(compact('notif', 'notify'));
    }

    /**
     * Show the application of itsolutionstuff.com.
     *
     * @return \Illuminate\Http\Response
     */
    public function ajaxRequest(Request $request){
        $user = User::find($request->user_id);
        if($done = auth()->user()->toggleFollow($user)){

            $response = array();
            $response[0] = ['s'=>$done];
            $response[1] = ['id'=>$request->user_id];
        }

        return response()->json(['ok'=>$response],200);
    }

    // public function notifications()
    // {
    //     return auth()->user()->unreadNotifications()->limit(5)->get()->toArray();
    // }

    public function ajaxRequestInsert(Request $request) {
        $uid = $request->id;
        $user = auth()->user()->id;
        $follow = Followable::where(['user_id' => $user, 'followable_id' => $uid, 'followable_type' => 'App\User'])
                                ->update(['notify'=>$uid]);
        // dump($follow);
        // return view('user.public');
        return response()->json(['success'],200);
    }
}
