<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row profile">
		<div class="col-md-3">
			<div class="profile-sidebar">
				<!-- SIDEBAR USERPIC -->
				<div class="profile-userpic">
					<img style="width:50%; height:50%; display:block; margin-left:auto; margin-right: auto;" src="/storage/cover_images/<?php echo e($owner->profile_image); ?>" class="img-responsive" alt="">
				</div>
				<!-- END SIDEBAR USERPIC -->
				<!-- SIDEBAR USER TITLE -->
				<div class="profile-usertitle">
					<div class="profile-usertitle-name">
						<?php echo e($owner->fname); ?> <?php echo e($owner->lname); ?>

					</div>
					<div class="profile-usertitle-job">
						<?php echo e($owner->job); ?>

					</div>
				</div>
				<!-- END SIDEBAR USER TITLE -->
                <?php if(auth()->guard()->guest()): ?>
                <div style="text-align: center">
                    <p><a href="<?php echo e(route('login')); ?>">Login</a> to follow this author.</p>
                </div>
                <?php else: ?>
				<!-- SIDEBAR BUTTONS -->
				<div class="profile-userbuttons">
                    <button type="button" id="buton" class="btn <?php echo e(auth()->user()->isFollowing($owner) ? 'btn-alert' : 'btn-success'); ?> btn-sm action-follow" data-id="<?php echo e($owner->id); ?>"><strong><?php echo e(!auth()->user()->isFollowing($owner) ? 'Follow' : 'Followed'); ?></strong></button>
                    <a href="<?php echo e(route('create', [$name = $owner->username])); ?>" style="text-decoration:none; color:white;"><button type="button" class="btn btn-danger btn-sm">Message</button></a>
				</div>
				<!-- END SIDEBAR BUTTONS -->
                <?php endif; ?>
				<!-- SIDEBAR MENU -->
				<div class="profile-usermenu">
                    <div class="profile-work">
                        <ul class="list-group">
                            <li class="list-group-item text-muted">Activity <i class="fa fa-dashboard fa-1x"></i></li>
                            <li class="list-group-item text-right"><span class="pull-left"><strong>Posts</strong></span><?php echo e(count($p)); ?></li>
                            <li class="list-group-item text-right"><span class="pull-left">Following :</span><strong><?php echo e($owner->followings()->get()->count()); ?></strong></li>
                            <li class="list-group-item text-right"><span class="pull-left">Followers :</span><strong class="tl-follower"><?php echo e($owner->followers()->get()->count()); ?></strong></li>
                        </ul> 
                    </div>
				</div>
				<!-- END MENU -->
			</div>
		</div>
		<div class="col-md-9">
            <div class="profile-content">
                <div class="col-md-6">
                    <div class="profile-head">
                                <h5>
                                    <b><?php echo e(strtoupper($owner->fname)); ?> <?php echo e(strtoupper($owner->lname)); ?></b>
                                </h5>
                                <h6>
                                    @<a href="<?php echo e(route('create', [$name = $owner->username])); ?>"><?php echo e($owner->username); ?></a> 
                                </h6>
                                <?php if(auth()->guard()->guest()): ?>
                                <?php else: ?>
                                <h6>
                                    <?php echo e($owner->email); ?>

                                </h6>
                                <?php endif; ?>
                                <p class="proile-rating"><q><?php echo e($owner->motto); ?></q> 
                                -<span class="author"><?php echo e($owner->fname); ?> <?php echo e($owner->lname); ?></span></p>
                        <ul class="nav nav-tabs" id="myTab" role="tablist">
                            <li class="nav-item">
                                <a class="nav-link active" id="profile-tab" data-toggle="tab" href="#profile" role="tab" aria-controls="profile" aria-selected="true">Personal</a>
                            </li>
                            <li>
                                <a href="#post" class="nav-link" id="post-tab" data-toggle="tab" role="tab" aria-controls="post" aria-selected="false">
                                <i class="glyphicon glyphicon-user"></i>
                                Post </a>
                            </li>
                            <li>
                                <a href="#overview" class="nav-link" id="overview-tab" data-toggle="tab" role="tab" aria-controls="overview" aria-selected="false">
                                <i class="glyphicon glyphicon-ok"></i>
                                Overview </a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-8" style="max-width: 100%;">
                        <div class="tab-content profile-tab" id="myTabContent">
                            <div class="tab-pane fade show active" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label>Status</label>
                                    </div>
                                    <div class="col-md-6">
                                        <p><?php echo e($owner->status); ?></p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label>Gender</label>
                                    </div>
                                    <div class="col-md-6">
                                        <select name="formGender" disabled="disabled">
                                            <option value="">Select...</option>
                                            <option value="l" name="gender" <?php echo e($owner->gender == 'l' ? 'selected' : ''); ?>>Male</option>
                                            <option value="f" name="gender" <?php echo e($owner->gender == 'f' ? 'selected' : ''); ?>>Female</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label>Birthtday</label>
                                    </div>
                                    <div class="col-md-6">
                                        <p><?php echo e($owner->bday); ?></p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label>Live in</label>
                                    </div>
                                    <div class="col-md-6">
                                        <p><?php echo e($owner->address); ?>,</p>
                                        <p><?php echo e($owner->city); ?> City, <?php echo e($owner->country); ?></p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label>Join</label>
                                    </div>
                                    <div class="col-md-6">
                                        <p><?php echo e($owner->created_at); ?></p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <label>Last login</label>
                                    </div>
                                    <div class="col-md-6">
                                        <p><?php echo e($owner->updated_at); ?></p>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <label>My Bio</label><br/>
                                        <p><?php echo e($owner->bio); ?></p>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="post" role="tabpanel" aria-labelledby="post-tab">
                                <div class="row">
                                    <div class="col-md-12">
                                        <label><?php echo e($owner->fname); ?> <?php echo e($owner->lname); ?>'s post</label><br/>
                                    </div>
                                </div>  
                                <div class="row">                                      
                                    <?php if(count($p) > 0): ?>
                                        <?php $__currentLoopData = $p; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-4 col-sm-4">
                                                <img style="width:100%" src="/storage/cover_images/<?php echo e($post->cover_image); ?>">
                                            </div>
                                            <div class="col-md-8 col-sm-8">
                                                <h3><a href="/posts/<?php echo e($post->id); ?>"><?php echo e($post->title); ?></a></h3>
                                                <small>Written on <?php echo e($post->created_at); ?> by <b style="color: #3490dc;"><?php echo e($post->user->fname); ?> <?php echo e($post->user->lname); ?></b></small>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($p->links()); ?>

                                    <?php else: ?>
                                        <p>No posts found</p>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="overview" role="tabpanel" aria-labelledby="overview-tab">
                                <div class="row">
                                <?php if(auth()->guard()->guest()): ?>
                                    <div class="col-md-12">
                                        <p><a href="<?php echo e(route('login')); ?>">Login</a> to comment about this author</p>
                                    </div>
                                <?php else: ?>
                                    <div class="col-md-12">
                                    
                                    </div>
                                <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>