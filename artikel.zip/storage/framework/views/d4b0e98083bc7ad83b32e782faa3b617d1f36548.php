<?php $__env->startSection('content'); ?>
<div class="col-sm-2">

</div>

<div class="col-md-8" >
    <div class="row">
        <h2>ACTIVITY</h2>
        <hr>
        <a href="<?php echo e(route('back')); ?>"><i class="fa fa-long-arrow-left" aria-hidden="true"></i> back</a>
    </div>      
    <hr>          
    <div class="row">
    <?php if(count($notify) > 0): ?>
        <div class="col">
            <ul class="list-group-striped">
                <?php $__currentLoopData = $notify; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="dropdown-header" style="padding: 0.5rem 0.5rem !important; word-break: break-word; width:100%; overflow:hidden; text-overflow:ellipsis;">
                        <?php if(empty($notification->relation)): ?>
                        <a href="/posts/<?php echo e($notification->pid); ?>" style="padding: 8px 12px !important"><?php echo e(\Carbon\Carbon::parse($notification->tgl)->diffforHumans()); ?> : <b style="color:blue"><?php echo e($notification->fullname); ?></b>
                        comment <b style="color:blue">"<?php echo e($notification->comment); ?>"</b> on your post <b style="color:blue">"<?php echo e($notification->post); ?>"</b>!</a>
                        <?php elseif($notification->relation == 'like'): ?>
                        <a href="/posts/<?php echo e($notification->pid); ?>" style="padding: 8px 12px !important"><?php echo e(\Carbon\Carbon::parse($notification->tgl)->diffforHumans()); ?> : <b style="color:blue"><?php echo e($notification->fullname); ?></b> <?php echo e($notification->relation); ?> your post <b style="color:blue">"<?php echo e($notification->post); ?>"</b>!</a>
                        <?php else: ?>
                        <a href="/profile/<?php echo e($notification->id); ?>" style="padding: 8px 12px !important"><?php echo e(\Carbon\Carbon::parse($notification->tgl)->diffforHumans()); ?> : <b style="color:blue"><?php echo e($notification->fullname); ?></b> <?php echo e($notification->relation); ?> you!</a>
                        <?php endif; ?>
                    </li>  
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
            </ul>

        </div> 
    <?php else: ?>
        <p style='text-align:center'>You don't have follower!</p>  
    <?php endif; ?>   
    </div>
</div>

<div class="col-sm-2">

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>