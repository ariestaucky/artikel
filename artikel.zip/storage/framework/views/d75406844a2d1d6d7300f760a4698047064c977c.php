<?php $__env->startSection('content'); ?>
<div class="col-md-8 blog-main">
    <div class="card">
        <div class="card-header">Dashboard</div>

        <div class="card-body">
            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>

           <p style="color: blue;">Welcome back <b style="color:black;"><?php echo e(Auth::user()->username); ?></b>!</p>
        </div>
        <div class="col-md-4" style="max-width: 100%;">

                <fieldset>
                    <legend>Basic Account Info:
                        <a href="<?php echo e(route('user.edit', Auth::user()->id)); ?>" class="profile-edit" style="float:right; font-size:medium;">
                            <button type="button" class="btn btn-primary btn-sm" title="Edit"><i class="fa fa-pencil" aria-hidden="true"></i> Edit</button>
                        </a>
                    </legend>
                        <table class="table" >
                            <tr>
                                <td>Full Name</td>
                                <td>:</td>
                                <td><p><?php echo e(Auth::user()->fname); ?> <?php echo e(Auth::user()->lname); ?></p></td>
                            </tr>
                            <tr>
                                <td>Username</td>
                                <td>:</td>
                                <td><p><?php echo e(Auth::user()->username); ?></p></td>
                            </tr>
                            <tr>
                                <td>Email</td>
                                <td>:</td>
                                <td><p><?php echo e(Auth::user()->email); ?> </p></td>
                            </tr>
                        </table>
                </fieldset>

        </div>
        <div class="col-md-4" style="max-width: 100%;">

                <fieldset>
                    <legend>Your Post:
                        <a href="<?php echo e(route('posts.create')); ?>" class="profile-edit" style="float:right; font-size:medium;">
                            <button type="button" class="btn btn-primary btn-sm" title="Create Post"><i class="fa fa-plus" aria-hidden="true"></i> Create</button>
                        </a>
                    </legend>
                    <?php if(count($po) > 0): ?>
                        <table class="table table-striped">
                            <tr>
                                <th>Title</th>
                                <th></th>
                                <th></th>
                            </tr>
                            <?php $__currentLoopData = $po; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><a href="/posts/<?php echo e($post->id); ?>" title="view <?php echo e($post->title); ?>"><?php echo e($post->title); ?></a></td>
                                    <td style="text-align:right;">
                                        <?php echo e($post->likers()->count()); ?> <small style="font-style:italic">Liked</small>/
                                        <?php echo e($post->comments->count()); ?> <small style="font-style:italic">comments</small>
                                    </td>
                                    <td style="text-align:right;">
                                        <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-default">Edit</a>
                                        <button type="button" class="btn btn-danger btn-sm" title="Delete" onclick=" document.getElementById('confirmDel').style.display = 'block'"><i class="fa fa-trash-o" aria-hidden="true"></i></button>

                                        <!-- Hidden confirmation modal -->
                                        <div class="modal overlay" id="confirmDel">
                                            <div class="modal-dialog">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h4 class="modal-title">Delete Confirmation</h4>
                                                    </div>
                                                    <div class="modal-body">
                                                        <p style="text-align:center;">Do you want to delete this?</p>
                                                    </div>
                                                    <div class="modal-footer">
                                                    <?php echo Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST']); ?>

                                                        <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                                                        <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger delete'])); ?>

                                                    <?php echo Form::close(); ?>              
                                                        <button type="button" class="btn btn-sm btn-default" data-dismiss="modal" onclick="document.getElementById('confirmDel').style.display = 'none'">Close</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- End of Hidden modal -->

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    <?php else: ?>
                        <p>You have no posts</p>
                    <?php endif; ?>
                </fieldset>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>