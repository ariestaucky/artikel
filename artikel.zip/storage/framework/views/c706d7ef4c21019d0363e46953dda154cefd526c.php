<?php $__env->startSection('show'); ?>
<div class="row">   
    <h1><?php echo e($post->title); ?></h1>
    <hr>
    <a href="<?php echo e(route('back')); ?>" class="btn btn-default">Go Back</a>
    <br>  
</div>
<div class="row">
     
    <hr>
    <small>Category : <?php echo e($post->kategori); ?></small> 
    <br>
    <br>
</div>
<div class="row">
    <img style="width:50%; height:50%; display:block; margin-left:auto; margin-right: auto;" src="/storage/cover_images/<?php echo e($post->cover_image); ?>">
    <br>
    <br>
    <div style="width:100%">
        <?php echo $post->body; ?>

    </div>
    <br>
    <br>
    <small>Written on <?php echo e($post->created_at); ?> by
        <?php if(auth()->guard()->guest()): ?>
        <a href="/profile/<?php echo e($post->user->id); ?>"><?php echo e($post->user->fname); ?> <?php echo e($post->user->lname); ?></a>
        <?php else: ?>
            <?php if($post->user->id == auth()->user()->id): ?>
            <a href="/user/<?php echo e(auth()->user()->id); ?>"><?php echo e($post->user->fname); ?> <?php echo e($post->user->lname); ?></a>
            <?php else: ?>
            <a href="/profile/<?php echo e($post->user->id); ?>"><?php echo e($post->user->fname); ?> <?php echo e($post->user->lname); ?></a>
            <?php endif; ?>
        <?php endif; ?>
    </small>
    <hr>
    <?php if(!Auth::guest()): ?>
        <?php if(Auth::user()->id == $post->user_id): ?>
            <a href="/posts/<?php echo e($post->id); ?>/edit" class="btn btn-default">Edit</a>

            <?php echo Form::open(['action' => ['PostsController@destroy', $post->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

                <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger', 'onclick' => 'return confirm("Are you sure?")'])); ?>

            <?php echo Form::close(); ?>

        <?php else: ?>
        <div class="panel-info" data-id="<?php echo e($post->id); ?>" data-user="<?php echo e($post->user->id); ?>">
            <div class="panel-footer">
                <span class="pull-right">
                    <h4><a href="#" title="Nature Portfolio" class="hidden"></a></h4>
                    <span class="like-btn" style="display: flex;">
                        <span class="give-like">Like 
                        <i id="like<?php echo e($post->id); ?>" class="fa fa-thumbs-o-up <?php echo e(auth()->user()->hasLiked($post) ? 'like-post' : ''); ?>"></i></span> <div id="like<?php echo e($post->id); ?>-bs3" class="thumb"><?php echo e($post->likers()->get()->count()); ?></div>
                    </span>
                </span>
            </div>
        </div>
        <?php endif; ?>
    <?php endif; ?>
</div>
<hr>
<div class="row">
    <h4 style="width:100%">Add comment</h4>
    <?php if(auth()->guard()->guest()): ?>
    <div style="text-align: left; width: 100%">
        <p><a href="<?php echo e(route('login')); ?>">Login</a>or <a href="<?php echo e(route('register')); ?>">create an account</a> to participate in this conversation.</p>
    </div>
    <?php else: ?>
    <div class="blog-comment">    
        <form method="post" action="<?php echo e(route('comment.add')); ?>" style="width:100%">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input type="text" name="body" id="comment_body" class="form-control" style="width:100%" required="required" />
                <input type="hidden" name="post_id" id="post_id" value="<?php echo e($post->id); ?>" />
                <input type="hidden" name="user_id" id="user_id" value="<?php echo e(Auth::user()->id); ?>" />
            </div>
            <div class="form-group">
                <input type="submit" class="btn btn-warning" value="Add Comment" />
            </div>
        </form>
    </div>
    <?php endif; ?>
    <hr>
<?php echo $__env->make('partials.coment', ['comments' => $post->comments, 'post_id' => $post->id], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div> 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>