<?php $__env->startSection('content'); ?>
    <!-- START THE FEATURETTES -->

    <hr class="featurette-divider">
    
    <?php $__currentLoopData = $pos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poster): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(++$count % 2 == 0): ?>
            <div class="row featurette">
                <div class="col-md-7">
                    <h2 class="featurette-heading"><?php echo e($poster->followable->title); ?></h2>
                        <span class="text-muted">Posted <?php echo e($poster->followable->created_at->diffforHumans()); ?> by
                            <a href="/profile/<?php echo e($poster->id); ?>"> <?php echo e($poster->fname); ?> <?php echo e($poster->lname); ?></a>
                        </span>
                        <hr>
                    <small>
                        <span class="give-like" style="font-size:16px">Like <i class="fa fa-thumbs-up" aria-hidden="true" style="cursor:default"></i></span><span class="thumb" style="font-size:16px"><?php echo e($poster->count); ?></span>
                    </small><br>
                    <p class="lead"><?php echo str_limit($poster->followable['body'], $limit = 400, $end = '...'); ?></p>
                    <a href="/posts/<?php echo e($poster->followable_id); ?>"><i class="fa fa-long-arrow-right" aria-hidden="true"></i> Continue reading</a>
                </div>
                <div class="col-md-5">
                    <img class="featurette-image img-fluid mx-auto" src="/storage/cover_images/<?php echo e($poster->followable->cover_image); ?>" alt="post image">
                </div>
            </div>

            <hr class="featurette-divider">
        <?php else: ?>
            <div class="row featurette">
                <div class="col-md-7 order-md-2">
                    <h2 class="featurette-heading"><?php echo e($poster->followable->title); ?></h2> <span class="text-muted">Posted <?php echo e($poster->followable->created_at->diffforHumans()); ?> by <a href="/profile/<?php echo e($poster->id); ?>"> <?php echo e($poster->fname); ?> <?php echo e($poster->lname); ?></a></span><hr>
                    <small>
                        <span class="give-like" style="font-size:16px">Like <i class="fa fa-thumbs-up" aria-hidden="true" style="cursor:default"></i></span><span class="thumb" style="font-size:16px"><?php echo e($poster->count); ?></span>
                    </small><br>
                    <p class="lead"><?php echo str_limit($poster->followable['body'], $limit = 400, $end = '...'); ?></p>
                    <a href="/posts/<?php echo e($poster->followable_id); ?>"><i class="fa fa-long-arrow-right" aria-hidden="true"></i> Continue reading</a>
                </div>
                <div class="col-md-5 order-md-1">
                    <img class="featurette-image img-fluid mx-auto" src="/storage/cover_images/<?php echo e($poster->followable->cover_image); ?>" alt="post image">
                </div>
            </div>

            <hr class="featurette-divider">
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- /END THE FEATURETTES -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>