<footer class="footer">
   <div class="container bottom_border">
      <div class="row">







      </div>
   </div>


   <div class="container">
      <ul class="foote_bottom_ul_amrc">
         <?php if(auth()->guard()->guest()): ?>
         <li><a href="/">Home</a></li>
         <?php else: ?>
         <li><a href="/dashboard">Home</a></li>
         <?php endif; ?>
         <li><a href="/about">About</a></li>
         <li><a href="/blog">Blog</a></li>
         <li><a href="/policies">Privacy Policy</a></li>
         <li><a href="/ToS">Term of Service</a></li>
         <li><a href="/contact-us">Contact Us</a></li>
      </ul>
   <!--foote_bottom_ul_amrc ends here-->
      <p class="text-center">Copyright @2019  | Designed With Bootstrap 4 by <a href="/">Artikel</a></p>

      <ul class="social_footer_ul">
         <li><a href="#"><i class="fa fa-facebook fab" aria-hidden="true"></i></a></li>
         <li style="padding-left:20px;"><a href="#"><i class="fa fa-twitter fab" aria-hidden="true"></i></a></li>
      </ul>
   <!--social_footer_ul ends here-->
   </div>
</footer>