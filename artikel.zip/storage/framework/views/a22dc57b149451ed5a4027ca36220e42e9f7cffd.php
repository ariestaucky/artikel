<?php $__env->startSection('content'); ?>
    <table class="table" id="tab1">
        <tr>
            <td>Full Name</td>
            <td>:</td>
            <td><?php echo e($user->fname); ?> <?php echo e($user->lname); ?></td>
        </tr>
        <tr>
            <td>Userame</td>
            <td>:</td>
            <td><?php echo e($user->username); ?></td>
        </tr>
        <tr>
            <td>E-mail</td>
            <td>:</td>
            <td><?php echo e($user->enail); ?></td>
        </tr>
        <tr>
            <!-- Quote container -->
            <div class="slideshow-container">
                <!-- quotes -->
                <div class="mySlides">
                    <q><?php echo e($user->motto); ?></q>
                    <p class="author">-<?php echo e($user->username); ?></p>
                </div>
            </div>
        </tr>
        <tr>
            <td>Short bio</td>
            <td>:</td>
            <td>
            <?php echo e($user->bio); ?>

            </td>
        </tr>
        <tr>
            <td>Gender </td>
            <td> :</td>
            <td>
            <?php echo e($user->gender); ?>

            </td>
        </tr>
        <tr>
            <td>Birthday      </td>
            <td> :</td>
            <td><?php echo e($user->bday); ?></td>
        </tr>
        <tr>
            <td>Status</td>
            <td>:</td>
            <td>
            <?php echo e($user->status); ?>

            </td>
        </tr>
        <tr>
            <td>City </td>
            <td> :</td>
            <td><?php echo e($user->city); ?></td>
        </tr>
        <tr>
            <td>Country </td>
            <td> :</td>
            <td><?php echo e($user->country); ?></td>
        </tr>
        <tr>
            <td>Address </td>
            <td> :</td>
            <td><?php echo e($user->address); ?></td>
        </tr>
        <tr>
            <td>Join date </td>
            <td> :</td>
            <td><?php echo e($user->create_at); ?></td>
        </tr>
        <tr>
            <td>Last seen </td>
            <td> :</td>
            <td><?php echo e($user->update_at); ?></td>
        </tr>
        <tr>
            <td></td><td></td><td><input type="button" class="up" onclick="location.href='update.php';" name="edit" value="Edit Profile"></td>
        </tr>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>