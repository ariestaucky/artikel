<?php $__env->startSection('content'); ?>
<div style="width: 65%;">
    <h1 style="padding: 0 20px; margin-right: 5px;">Create Post</h1>
    <?php echo Form::open(['action' => 'PostsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

        <div class="form-group">
            <?php echo e(Form::label('title', 'Title')); ?>

            <?php echo e(Form::text('title', '', ['class' => 'form-control', 'placeholder' => 'Title'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::select('kategori', ['Politic' => 'Politic', 'Economy' => 'Economy', 'Sport' => 'Sport', 'Social'=> 'Social', 'Culture' => 'Culture', 'Sains&Technology' => 'Sains&Technology', 'Religious' => 'Religious', 'General' => 'General'], 'General')); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('body', 'Posts')); ?>

            <?php echo e(Form::textarea('body', '', ['id' => 'article-ckeditor', 'class' => 'form-control', 'placeholder' => 'Your posts'])); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::file('cover_image')); ?>

        </div>
        <div>
            <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary', 'style' => 'width: 100px; border-radius: inherit;'])); ?>

        </div>
    <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>