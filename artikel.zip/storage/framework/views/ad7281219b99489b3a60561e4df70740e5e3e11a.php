<?php $__env->startSection('content'); ?>
<div class="col-md-8 blog-main">
    <h2><?php echo e($cat); ?></h2>   
    <div class="col-md-4">        
        <p><?php echo e($pos->count()); ?> Total posts</p>
        <hr>
    </div>
    <?php if(count($pos) > 0): ?>
        <?php $__currentLoopData = $pos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="blog-post">
            <div class="row">
                <h3 style="width:100%"><a href="/posts/<?php echo e($data->id); ?>"><?php echo e($data->title); ?></a></h3>
                <div class="col-md-4 col-sm-4">
                    <img style="width:100%" src="/storage/cover_images/<?php echo e($data->cover_image); ?>">
                </div>
                <div class="col-md-8 col-sm-8">    
                    <small>Category : <?php echo e($data->kategori); ?></small><hr>
                    <small>Written on <?php echo e($data->created_at); ?> by 
                        <b style="color: #3490dc;">
                        <?php if(auth()->guard()->guest()): ?>
                        <a href="/profile/<?php echo e($data->user->id); ?>"><?php echo e($data->user->fname); ?> <?php echo e($data->user->lname); ?></a>
                        <?php else: ?>
                            <?php if($data->user->id == auth()->user()->id): ?>
                            <a href="/user/<?php echo e(auth()->user()->id); ?>"><?php echo e($data->user->fname); ?> <?php echo e($data->user->lname); ?></a>
                            <?php else: ?>
                            <a href="/profile/<?php echo e($data->user->id); ?>"><?php echo e($data->user->fname); ?> <?php echo e($data->user->lname); ?></a>
                            <?php endif; ?>
                        <?php endif; ?>
                        </b>
                    </small>
                </div>
            </div>
        </div>
        <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
        <p>No posts found</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>