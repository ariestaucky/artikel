<?php $__env->startSection('content'); ?>
<div class="col-sm-2">

</div>
    <?php if(isset($follower)): ?>
        <div class="col-md-8" >
            <div class="row">
                <h2>Follower</h2>
                <hr>
                <a href="<?php echo e(route('back')); ?>"><i class="fa fa-long-arrow-left" aria-hidden="true"></i> back</a>
            </div>      
            <hr>          
            <small><?php echo e(Auth::user()->followers()->get()->count()); ?> Total followers</small>
            <div class="row">
            <?php if(count($follower) > 0): ?>
            <?php $__currentLoopData = $follower; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-4">
                    <div class="panel">
                        <div class="image">
                            <img src="/storage/cover_images/<?php echo e($follower->profile_image); ?>" alt="" width="100%" height="100%" style="border-radius: 50%;">
                        </div>
                        <hr>
                        <p style="width:100%; margin-bottom: 1px !important; text-align:center"><a href="<?php echo e(route('create', [$name = $follower->username])); ?>" title="Send Message" ><?php echo e($follower->fname); ?> <?php echo e($follower->lname); ?></a></p>
                    </div>
                </div>      
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
            <?php else: ?>
                <p style='text-align:center'>You don't have follower!</p>  
            <?php endif; ?>   
            </div>
        </div>
    <?php endif; ?>

    <?php if(isset($following)): ?>
        <div class="col-md-8" >
            <div class="row">
                <h2>Following</h2>
                <hr>
                <a href="<?php echo e(route('back')); ?>"><i class="fa fa-long-arrow-left" aria-hidden="true"></i> back</a>
            </div>
            <hr>
            <small><?php echo e(Auth::user()->followings()->get()->count()); ?> Total following</small>
            <div class="row">
            <?php if(count($following) > 0): ?>
            <?php $__currentLoopData = $following; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $following): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-4">
                    <div class="panel">
                        <div class="image">
                            <img src="/storage/cover_images/<?php echo e($following->profile_image); ?>" alt="" width="100%" height="100%" style="border-radius: 50%;">
                        </div>
                        <hr>
                        <p style="width:100%; margin-bottom: 1px !important; text-align:center"><a href="<?php echo e(route('create', [$name = $following->username])); ?>" title="Send Message" ><?php echo e($following->fname); ?> <?php echo e($following->lname); ?></a></p>
                    </div>
                </div>        
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
            <?php else: ?>
                <p style='text-align:center'>You are not following anyone!</p>  
            <?php endif; ?>          
            </div>
        </div>
    <?php endif; ?>
<div class="col-sm-2">

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>