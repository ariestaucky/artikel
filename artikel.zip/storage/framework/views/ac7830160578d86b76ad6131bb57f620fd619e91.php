<?php $__env->startSection('content'); ?>
<div class="col-md-8 blog-main">
    <h3 class="pb-3 mb-4 font-italic border-bottom">
    <!-- From the Firehose -->
    </h3>
    <?php if(count($posts) > 0): ?>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="blog-post">
            <div class="row">
                <h2 class="blog-post-title"><?php echo e($post->title); ?></h2>
                <hr>
                <a href="/posts/<?php echo e($post->id); ?>" class="profile-edit"><input class="profile-edit-btn" name="btnAddMore" value="View post"/></a>
            </div>
            <small>Category : <?php echo e($post->kategori); ?></small><br>
            <small class="blog-post-meta"><?php echo e($post->created_at); ?> by 
                <?php if(auth()->guard()->guest()): ?>
                <a href="/profile/<?php echo e($post->user->id); ?>"><?php echo e($post->user->fname); ?> <?php echo e($post->user->lname); ?></a>
                <?php else: ?>
                    <?php if($post->user->id == auth()->user()->id): ?>
                    <a href="/user/<?php echo e(auth()->user()->id); ?>"><?php echo e($post->user->fname); ?> <?php echo e($post->user->lname); ?></a>
                    <?php else: ?>
                    <a href="/profile/<?php echo e($post->user->id); ?>"><?php echo e($post->user->fname); ?> <?php echo e($post->user->lname); ?></a>
                    <?php endif; ?>
                <?php endif; ?>
            </small>
            <img style="width:50%; height:50%; display:block; margin-left:auto; margin-right: auto;" src="/storage/cover_images/<?php echo e($post->cover_image); ?>">
            <br><br>
            <p><?php echo $post->body; ?></p>
            <hr>
            <i class="fa fa-comments-o" aria-hidden="true" style="cursor:default"></i> <?php echo e($post->comments->count()); ?> <small style="color:#3490dc">comments</small> &nbsp;&nbsp;
            <i class="fa fa-thumbs-up" aria-hidden="true" style="cursor:default"></i> <?php echo e($post->likers()->get()->count()); ?> <small style="color:#3490dc">likes</small>
        </div><!-- /.blog-post -->
        <hr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($posts->links()); ?>

    <?php else: ?>
        <p>No posts found</p>
    <?php endif; ?>
</div><!-- /.blog-main -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>