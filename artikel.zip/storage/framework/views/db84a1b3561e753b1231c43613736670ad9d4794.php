<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Artikel')); ?></title>

    <!-- Fonts -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Nunito" type="text/css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Varela+Round">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">

    <!-- Styles -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">

</head> 
<body>

<main role="main" class="container">
    <div class="row">
        <div class="card col-md-8 mx-auto">
            <h5 class="card-header">WELCOME</h5>
            <div class="card-body">
                <div class="row">
                    <div class="col-4 mx-auto text-center">
                        <img src="<?php echo e(asset('/public/cover_images/' . auth()->user()->profile_image)); ?>" class="img-fluid centered-img" alt="Responsive image">
                    </div>
                </div>
                <h5 class="card-title text-center">Hi <strong><?php echo e(auth()->user()->fname); ?> <?php echo e(auth()->user()->lname); ?>!</strong></h5>
                <p class="card-text text-center">To complate your registration, please enter your new password for Artikel!</p>
                <hr>
                <form class="form-horizontal" role="form" method="POST" action="<?php echo e(route('complete', auth()->user()->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <p class="card-text text-center">Your account detail!</p>
                    <div class="form-group form-inline">
                        <div class="col-sm-6">
                            <label class="col-md-6 control-label" style="justify-content:left !important">Email</label>
                            <div class="col-md-10">
                            <p class="form-control-static"><?php echo e(auth()->user()->email); ?></p>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <label class="col-md-6 control-label" style="justify-content:left !important">Usename</label>
                            <div class="col-md-10">
                            <p class="form-control-static"><?php echo e(auth()->user()->username); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                        <label for="inputPassword" class="col-md-6 control-label">Password</label>
                        <div class="col">
                            <input type="password" class="form-control" id="inputPassword" placeholder="Password" name="password" required>
                            <?php if($errors->has('password')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('password')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="password-confirm" class="col-md-6 control-label">Confirm</label>
                        <div class="col">
                            <input type="password" class="form-control" id="password-confirm" placeholder="Confirm" name="password_confirmation" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="col-md-6" style="text-align: center;width: 100%;">
                            <button type="submit" class="btn btn-primary">
                                Complete
                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>

    <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/custom.js')); ?>" defer></script>
    <script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>

</body>
</html>  